<?php
//数据库连接信息
$cfg_dbhost = 'localhost';
$cfg_dbname = 'b0008_mysitecdn';
$cfg_dbuser = 'b0008_mysitecdn';
$cfg_dbpwd = 'xx19960908xx';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>