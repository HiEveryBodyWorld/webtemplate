<?php
//数据库连接信息
$cfg_dbtype = 'mysql';
$cfg_dbhost = 'localhost';
$cfg_dbname = '';
$cfg_dbuser = '';
$cfg_dbpwd = '';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';


?>
        